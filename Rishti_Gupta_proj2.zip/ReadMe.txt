To run the test.py, use this command :

python3 test.py <argument>

where argument is the test file name. 